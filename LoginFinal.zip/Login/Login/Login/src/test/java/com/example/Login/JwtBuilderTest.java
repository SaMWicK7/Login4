package com.example.Login;

import com.example.Login.Model.JwtProperties;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Header;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.json.JsonTest;

import java.security.*;
import java.security.spec.*;
import java.util.Calendar;
import java.util.Date;

@JsonTest
@EnableConfigurationProperties(value = JwtProperties.class)
public class JwtBuilderTest {
    @Autowired
    private JwtProperties jwtProperties;

    @Test
    public void jwtTest() {
//        try {
//            // Create a KeyPairGenerator object for RSA
//            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
//
//            // Initialize the generator with a key size of 2048 bits
//            keyPairGen.initialize(2048);
//
//            // Generate a new key pair
//            KeyPair keyPair = keyPairGen.generateKeyPair();
//
//            // Get the public and private keys
//            byte[] publicKey = keyPair.getPublic().getEncoded();
//            byte[] privateKey = keyPair.getPrivate().getEncoded();
//
//            String PUB_KEY = Base64.getEncoder().encodeToString(publicKey);
//            String PRIV_KEY = Base64.getEncoder().encodeToString(privateKey);
//
//            // Generated Keys in String Form
//            System.out.println("publicKey : " + Base64.getEncoder().encodeToString(publicKey));
//            System.out.println("PrivateKey : " +  Base64.getEncoder().encodeToString(privateKey));
//
//
//            // As they are Long we use the Another Encoders to indicate start and end to the Keys their size
//            X509EncodedKeySpec initSpecPublic = new X509EncodedKeySpec(publicKey);
//            PKCS8EncodedKeySpec initSpecPrivate = new PKCS8EncodedKeySpec(privateKey);
//
//            System.out.println("publicKey : " + Base64.getEncoder().encodeToString(initSpecPublic.getEncoded()));
//            System.out.println("PrivateKey : " +  Base64.getEncoder().encodeToString(initSpecPrivate.getEncoded()));
//
//
//            //Key Factory
//            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//
//            //Genetrating the Keys again
//
//
//
//        } catch (NoSuchAlgorithmException e) {
//            System.err.println("Error generating RSA key pair: " + e.getMessage());
//        }
//    }
    }

    @Test
    public void keyPairs() throws NoSuchAlgorithmException, InvalidKeySpecException {
        KeyFactory kf = KeyFactory.getInstance("RSA");

        String publicKeyEncoded = jwtProperties.getPublicKey();
        PublicKey publicKey = kf.generatePublic(new X509EncodedKeySpec(Decoders.BASE64.decode(publicKeyEncoded)));

        String privateKeyEncoded = jwtProperties.getPrivateKey();
        PrivateKey privateKey = kf.generatePrivate(new PKCS8EncodedKeySpec(Decoders.BASE64.decode(privateKeyEncoded)));

        Calendar calendar = Calendar.getInstance();
        Date issuedAt = calendar.getTime();
        calendar.add(Calendar.HOUR_OF_DAY,1);
        Date expiration = calendar.getTime();

        Calendar.getInstance().getTime();
        String jwtString = Jwts.builder()
                .setIssuer("Login")
                .setSubject("JWTToken")
                .setIssuedAt(issuedAt)
                .setExpiration(expiration)
                .setHeaderParam(Header.TYPE, Header.JWT_TYPE)
                .claim("username", "username")
                .claim("password", "password")
                .signWith(privateKey)
                .compact();

        System.out.println("jwt Token \n  " + jwtString);

        Jws<Claims> jws = Jwts.parserBuilder()
                .setSigningKey(publicKey)
                .build().parseClaimsJws(jwtString);
        System.out.println("jws : " + jws);
    }
}
