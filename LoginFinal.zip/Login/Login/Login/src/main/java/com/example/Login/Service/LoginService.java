package com.example.Login.Service;

import com.example.Login.Model.JwtProperties;
import com.example.Login.Model.Login;
import com.example.Login.Repository.LoginRepository;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Optional;

@Service
public class LoginService {

    private final LoginRepository loginRepository;
    private final JwtProperties jwtProperties;

    @Autowired
    public LoginService(LoginRepository loginRepository, JwtProperties jwtProperties) {
        this.loginRepository = loginRepository;
        this.jwtProperties = jwtProperties;
    }

    public String authenticate(String username, String password, PrivateKey privateKey) {
        Optional<Login> loginOptional = loginRepository.findByUsername(username);
        Instant now = Instant.now();
        Date issuedAt = Date.from(now);
        Date expiration = Date.from(now.plus(1, ChronoUnit.HOURS));

        if (loginOptional.isPresent()) {
            Login login = loginOptional.get();
            if (!password.equals(login.getTemporaryPassword()) && !password.equals(login.getPermanentPassword())) {
                throw new RuntimeException("Invalid password");
            }
            JwtBuilder jwtBuilder = Jwts.builder();
            jwtBuilder.setSubject("JWTToken");
            jwtBuilder.setIssuer("Login");
            jwtBuilder.claim("username", username);
            jwtBuilder.claim("password", password);
            jwtBuilder.setIssuedAt(issuedAt);
            jwtBuilder.setExpiration(expiration);
            jwtBuilder.signWith(privateKey);
            return jwtBuilder.compact();
        } else {
            throw new RuntimeException("Invalid username/password");
        }
    }
}
