package com.example.Login.Controller;

import com.example.Login.Model.JwtProperties;
import com.example.Login.Model.JwtTokenRestResponse;
import com.example.Login.Model.LoginRestRequest;
import com.example.Login.Service.LoginService;
import jakarta.annotation.PostConstruct;
import org.bouncycastle.util.encoders.Base64;
import org.springframework.web.bind.annotation.*;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;


@RestController
@RequestMapping("/mams")
public class LoginController {
    private final LoginService loginService;
    private final JwtProperties jwtProperties;
    private PrivateKey privateKey;

    public LoginController(LoginService loginService, JwtProperties jwtProperties) {
        this.loginService = loginService;
        this.jwtProperties = jwtProperties;
    }

    @PostConstruct
    public void init() throws NoSuchAlgorithmException, InvalidKeySpecException {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec initSpecPublic = new X509EncodedKeySpec(Base64.decode(jwtProperties.getPublicKey()));
        PublicKey publicKey = keyFactory.generatePublic(initSpecPublic);
        PKCS8EncodedKeySpec initSpecPrivate = new PKCS8EncodedKeySpec(Base64.decode(jwtProperties.getPrivateKey()));
        privateKey = keyFactory.generatePrivate(initSpecPrivate);
    }

    @PostMapping("/createJwtToken")
    public JwtTokenRestResponse createJwtToken(@RequestBody LoginRestRequest request) {
        String token = loginService.authenticate(request.getUserName(), request.getPassword(), privateKey);
        return JwtTokenRestResponse.builder().token(token).build();
    }

}
