package com.example.Login.Repository;

import org.springframework.stereotype.Repository;

@Repository
public class LoginRepositoryImpl {

}
