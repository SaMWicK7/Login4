package com.example.Login.Model;


import lombok.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "login")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class JwtProperties {
    @Value("${login.jwtPublicKey}")
    private String publicKey;
    @Value ("${login.jwtPrivateKey}")
    private String privateKey;
}
