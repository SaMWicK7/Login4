package com.example.Login.Model;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class LoginRestRequest {
    private String userName;
    private String password;
}
