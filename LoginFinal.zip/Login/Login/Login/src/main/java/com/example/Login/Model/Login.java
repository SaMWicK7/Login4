package com.example.Login.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "patient_details_tbl")
@Table
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Login {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "patient_id")
    private String userName;
    @Column(name = "temp_password_status")
    private String temporaryPassword;

    @Column(name = "permanent_password")
    private String permanentPassword;

}
